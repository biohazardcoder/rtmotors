import mongoose from "mongoose";

const CustomerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    message:{
        type: String,
        required: true,
    }
},{timestamps: true});


export default mongoose.model("Customer", CustomerSchema);